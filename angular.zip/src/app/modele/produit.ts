export interface Produit {
    id:number
    nom:string
    prix:number
    quantite:number
    urlImage:string 
    
}
